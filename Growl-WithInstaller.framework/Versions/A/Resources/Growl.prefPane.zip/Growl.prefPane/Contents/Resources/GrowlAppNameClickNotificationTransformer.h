//
//  GrowlAppNameClickNotificationTransformer.h
//  Growl
//
//  Created by Evan Schoenberg on 5/25/07.
//

#import <Cocoa/Cocoa.h>


@interface GrowlAppNameClickNotificationTransformer : NSValueTransformer {

}

@end
