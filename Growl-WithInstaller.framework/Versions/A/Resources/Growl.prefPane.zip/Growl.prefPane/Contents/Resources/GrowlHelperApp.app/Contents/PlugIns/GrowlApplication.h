//
//  GrowlApplication.h
//  Growl
//
//  Created by Evan Schoenberg on 5/10/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface GrowlApplication : NSApplication {

}

@end
