//
//  NotificationsArrayController.h
//  Growl
//
//  Created by Evan Schoenberg on 12/24/05.
//

#import <Cocoa/Cocoa.h>


@interface NotificationsArrayController : NSArrayController {

}

@end
